package com.zaptech.attd;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.support.v4.app.FragmentActivity;
import android.app.Dialog;
import android.app.DatePickerDialog;
import android.support.v4.app.DialogFragment;
 
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
 
public class attandance extends FragmentActivity {
	 public Spinner spinner1 ,spinner2 ,spinner3 ,spinner4,spinner5;
 
EditText mEdit;
@Override
public void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
setContentView(R.layout.attdform);
addItemsOnSpinner1();
//addListenerOnSpinnerItemSelection();
}
 
public void addItemsOnSpinner1() {
	// TODO Auto-generated method stub
	spinner1 = (Spinner) findViewById(R.id.spinner1);
	List<String> list = new ArrayList<String>();
	list.add("Digree Engineering");
	list.add("Diploma Engineering");

	ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
		android.R.layout.simple_spinner_item, list);
	dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	spinner1.setAdapter(dataAdapter);
	
	
	
}
/*public void addListenerOnSpinnerItemSelection() {
	spinner1 = (Spinner) findViewById(R.id.spinner1);
	spinner1.setOnItemSelectedListener(new CustomOnItemSelectedListener());
	
	spinner2 = (Spinner) findViewById(R.id.spinner2);
	spinner2.setOnItemSelectedListener(new CustomOnItemSelectedListener());
	
	spinner3 = (Spinner) findViewById(R.id.spinner3);
	spinner3.setOnItemSelectedListener(new CustomOnItemSelectedListener());
	
	spinner4 = (Spinner) findViewById(R.id.spinner4);
	spinner4.setOnItemSelectedListener(new CustomOnItemSelectedListener());
	
	spinner5 = (Spinner) findViewById(R.id.spinner5);
	spinner5.setOnItemSelectedListener(new CustomOnItemSelectedListener());

}*/
public void addItemsOnSpinner2() {
	// TODO Auto-generated method stub
	spinner2 = (Spinner) findViewById(R.id.spinner2);
	List<String> list = new ArrayList<String>();
	list.add("C.E Dept");
	list.add("I.T Dept");
	list.add("E.E Dept");
	list.add("Mech Dept");
	list.add("Civil Dept");
	
	ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
		android.R.layout.simple_spinner_item, list);
	dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	spinner2.setAdapter(dataAdapter);
	
	
}
public void addItemsOnSpinner3() {
	// TODO Auto-generated method stub
	spinner3 = (Spinner) findViewById(R.id.spinner3);
	List<String> list = new ArrayList<String>();
	list.add("1");
	list.add("2");
	list.add("3");
	list.add("4");
	list.add("5");
	list.add("6");
	list.add("7");
	list.add("8");
	
	ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
		android.R.layout.simple_spinner_item, list);
	dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	spinner3.setAdapter(dataAdapter);
	
}

public void addItemsOnSpinner4() {
	// TODO Auto-generated method stub
	spinner4 = (Spinner) findViewById(R.id.spinner4);
	List<String> list = new ArrayList<String>();
	list.add("Sub1");
	list.add("Sub2");
	list.add("Sub3");
	list.add("Sub4");
	list.add("Sub5");
	list.add("Sub6");
	
	
	ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
		android.R.layout.simple_spinner_item, list);
	dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	spinner4.setAdapter(dataAdapter);
	
}

public void addItemsOnSpinner5() {
	// TODO Auto-generated method stub
	spinner5 = (Spinner) findViewById(R.id.spinner5);
	List<String> list = new ArrayList<String>();
	list.add("Lec1");
	list.add("Lec2");
	list.add("Lec3");
	list.add("Lec4");
	list.add("Lec5");
	list.add("Lec6");	
	ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
		android.R.layout.simple_spinner_item, list);
	dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	spinner5.setAdapter(dataAdapter);
	
	
}

public void setdatemethod(View view) {
DialogFragment newFragment = new SelectDateFragment();
newFragment.show(getSupportFragmentManager(), "DatePicker");
}
public void populateSetDate(int year, int month, int day) {
mEdit = (EditText)findViewById(R.id.EditText01);
mEdit.setText(month+"/"+day+"/"+year);
}
public class SelectDateFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
@Override
public Dialog onCreateDialog(Bundle savedInstanceState) {
final Calendar calendar = Calendar.getInstance();
int yy = calendar.get(Calendar.YEAR);
int mm = calendar.get(Calendar.MONTH);
int dd = calendar.get(Calendar.DAY_OF_MONTH);
return new DatePickerDialog(getActivity(), this, yy, mm, dd);
}
 
public void onDateSet(DatePicker view, int yy, int mm, int dd) {
populateSetDate(yy, mm+1, dd);
}
}
 
}